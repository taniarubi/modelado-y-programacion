import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		/* La baguette. */
		Baguette baguette;

		System.out.println("¡Bienvenido a WaySub! \n" + "Indique el número del " + 
						   "producto que desea ordenar: \n" + "1 -> Baguette \n" + 
						   "2 -> Pizza");

		try {
			Scanner respuesta = new Scanner(System.in);
			int opcionProducto = respuesta.nextInt();

			switch(opcionProducto) {
				case 1:
					System.out.println("Escoja el tipo de pan para su baguette:\n" + 
									"1 -> Pan Tradicional\n" + 
									"2 -> Pan Integral\n" + "3 -> Pan libre de " + 
									"gluten\n");
					respuesta = new Scanner(System.in);
					int opcionPan = respuesta.nextInt();
					switch(opcionPan) {
						case 1: 
							baguette = new BaguettePanTradicional();
							System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
							System.out.println("Costo: $" + baguette.getCosto() + 
							                   "\n");
							break;
						case 2:
							baguette = new BaguettePanIntegral();
							System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
							System.out.println("Costo: $" + baguette.getCosto() + 
							                   "\n");
							break;
						case 3: 
							baguette = new BaguettePanLibreDeGluten();
							System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
							System.out.println("Costo: $" + baguette.getCosto() + 
							                   "\n");
							break; 
						default: 
							baguette = new BaguettePanTradicional();
							System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
							System.out.println("Costo: $" + baguette.getCosto() + 
							                   "\n");
					}

					int opcionIngrediente = 0; 

					do {
						System.out.println("Ahora puede elegir los ingredientes para " + 
									   "su Baguette.\n" + "Por favor, elija los " + 
									   "ingredientes:\n" + "1 -> Pollo\n" + 
									   "2 -> Pepperoni\n" + "3 -> Jamón\n" + 
									   "4 -> Lechuga\n" + "5 -> Jitomate\n" + 
									   "6 -> Cebolla\n" + "7 -> Mostaza\n" + 
									   "8 -> Catsup\n" + "9 -> Mayonesa\n" +
									   "10 -> Terminar de elegir ingredientes\n");

						respuesta = new Scanner(System.in);
						opcionIngrediente = respuesta.nextInt();

						switch(opcionIngrediente) {
							case 1: 
								baguette = new ConPollo(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break; 
							case 2:
								baguette = new ConPepperoni(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break; 
							case 3:
								baguette = new ConJamon(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break; 
							case 4:
								baguette = new ConLechuga(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break;
							case 5:
								baguette = new ConJitomate(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break; 
							case 6:
								baguette = new ConCebolla(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break;
							case 7: 
								baguette = new ConMostaza(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break;
							case 8:
								baguette = new ConCatsup(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break; 
							case 9:
								baguette = new ConMayonesa(baguette);
								System.out.println("Ingredientes: \n" + 
							                   baguette.getDescripcion() + "\n");
								System.out.println("Costo: $" + 
								                   baguette.getCosto() + "\n");
								break;
							case 10:
								opcionIngrediente = 150;
								break;
							default:
								System.out.println("Ingrediente inválido. Por " + 
												   "favor, intente de nuevo.");
								break; 
						}
					} while((opcionIngrediente >= 1) && (opcionIngrediente <= 10));

					System.out.println("\nUsted pagaría $" + baguette.getCosto() + 
									   " por una baguette con los siguientes " + 
									   "ingredientes: \n" + 
									   baguette.getDescripcion());
					break;
				case 2:
					System.out.println("");
					break;
				default:
					System.out.println("Opción inválida de producto. Por favor, " + 
					                   "intente de nuevo. \n");
			}

		} catch(Exception e) {
			System.out.println("Error de entrada.");
		}

	}
}
